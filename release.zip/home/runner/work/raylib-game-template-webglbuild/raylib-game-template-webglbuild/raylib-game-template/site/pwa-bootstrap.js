if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/raylib-game-template-webglbuild/sw.js');
}
